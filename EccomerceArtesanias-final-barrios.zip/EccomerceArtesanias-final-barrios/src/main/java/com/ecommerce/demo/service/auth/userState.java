package com.ecommerce.demo.service.auth;

public class userState {

}
