package com.ecommerce.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommerceJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
