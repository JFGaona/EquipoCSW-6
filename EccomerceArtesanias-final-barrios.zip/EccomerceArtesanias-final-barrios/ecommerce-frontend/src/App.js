import React from 'react';
import './App.css';
import Producto from './Producto';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <div className="App">
      <Producto />
    </div>
  );
}

export default App;
